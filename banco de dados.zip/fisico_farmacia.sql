DROP DATABASE FARMACIA;
CREATE DATABASE FARMACIA;
USE FARMACIA;

CREATE TABLE CARGO (
    id_cargo INTEGER PRIMARY KEY AUTO_INCREMENT,
    nome_cargo VARCHAR(255) UNIQUE NOT NULL,
    carga_horaria INTEGER,
    salario DOUBLE
);

CREATE TABLE FUNCIONARIO (
    id_funcionario INTEGER PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(255) NOT NULL,
    cpf VARCHAR(11) UNIQUE NOT NULL,
    data_nascimento DATE NOT NULL,
    endereco VARCHAR(255) NOT NULL,
    telefone VARCHAR(20) NOT NULL,
    email VARCHAR(100),
    data_contratado DATE,
    id_cargo INTEGER NOT NULL,
    FOREIGN KEY (id_cargo)
        REFERENCES CARGO (id_cargo)
        ON DELETE RESTRICT
);

CREATE TABLE FABRICANTE (
    id_fabricante INTEGER PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(255) NOT NULL,
    telefone VARCHAR(20) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    cnpj VARCHAR(14) UNIQUE NOT NULL,
    endereco VARCHAR(255) NOT NULL
);


CREATE TABLE MEDICAMENTO (
    id_medicamento INTEGER PRIMARY KEY AUTO_INCREMENT,
    nome VARCHAR(255) NOT NULL,
    valor_unidade DOUBLE NOT NULL,
    estoque INTEGER NOT NULL,
    id_fabricante INTEGER NOT NULL,
    FOREIGN KEY (id_fabricante)
        REFERENCES FABRICANTE (id_fabricante)
        ON DELETE RESTRICT
);

CREATE TABLE CLIENTE (
    id_cliente INTEGER PRIMARY KEY AUTO_INCREMENT,
    cpf VARCHAR(11) UNIQUE NOT NULL,
    nome VARCHAR(255) NOT NULL,
    data_nascimento DATE NOT NULL,
    data_cadastro DATE NOT NULL,
    telefone VARCHAR(20) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    endereco VARCHAR(255) NOT NULL
);

CREATE TABLE PEDIDO (
    id_pedido INTEGER PRIMARY KEY AUTO_INCREMENT,
    data DATE NOT NULL,
    valor_total DOUBLE NOT NULL,
    id_cliente INTEGER NOT NULL,
    id_funcionario INTEGER NOT NULL,
    FOREIGN KEY (id_cliente) 
        REFERENCES CLIENTE (id_cliente)
        ON DELETE RESTRICT,
    FOREIGN KEY (id_funcionario) 
        REFERENCES FUNCIONARIO (id_funcionario)
        ON DELETE RESTRICT
);

CREATE TABLE INCLUIR (
    id_pedido INTEGER,
    id_medicamento INTEGER,
    FOREIGN KEY (id_pedido) 
        REFERENCES PEDIDO (id_pedido)
        ON DELETE RESTRICT,
    FOREIGN KEY (id_medicamento) 
        REFERENCES MEDICAMENTO (id_medicamento)
        ON DELETE RESTRICT
);

INSERT INTO CARGO (nome_cargo, carga_horaria, salario) 
VALUES 
    ('Gerente', 40, 4000.00),
    ('Farmacêutico', 40, 3000.00),
    ('Vendedor', 40, 2500.00),
    ('Assistente de Farmácia', 30, 2000.00),
    ('Estoquista', 35, 1800.00);

INSERT INTO FUNCIONARIO (nome, cpf, data_nascimento, endereco, telefone, email, data_contratado, id_cargo) 
VALUES 
    ('João Silva', '12345678901', '2001-02-23', 'Rua Principal, 123', '61987654321', 'joaosilva423@email.com', '2023-08-09', 1),
    ('Maria Santos', '98765432101', '2003-02-03', 'Avenida Central, 456', '61987654322', 'mariasantos34@email.com', '2023-06-13', 2),
    ('Pedro Oliveira', '78901234501', '2004-04-04', 'Rua Comercial, 789', '61987654323', 'pedrooliveira3124@email.com', '2023-02-23', 3),
    ('Ana Costa', '34567890101', '2008-05-13', 'Praça da Farmácia, 321', '61987654324', 'anacorsta312@email.com', '2023-05-20', 4),
    ('Luiz Pereira', '56789012301', '2002-08-07', 'Alameda do Estoque, 567', '61987654325', 'luizpereira1234@email.com', '2023-06-04', 5);

INSERT INTO CLIENTE (cpf, nome, data_nascimento, data_cadastro, telefone, email, endereco) 
VALUES 
    ('11122233344', 'Carlos Oliveira', '1990-08-15', '2023-03-04', '61987654321', 'carlosoliveira23@email.com', 'Rua Principal, 123'),
    ('22233344455', 'Patrícia Silva', '1985-05-20', '2023-05-14', '61987654322', 'patriciasilva312@email.com', 'Avenida Central, 456'),
    ('33344455566', 'Fernando Santos', '1982-12-10', '2023-07-15', '61987654323', 'fernandosantos542@email.com', 'Rua Comercial, 789'),
    ('44455566677', 'Juliana Costa', '1995-03-25', '2023-09-25', '61987654324', 'julianacosta234@email.com', 'Praça da Farmácia, 321'),
    ('55566677788', 'Mariana Pereira', '1988-07-02', '2023-01-05', '61987654325', 'marianapereira45@email.com', 'Alameda do Estoque, 567');

INSERT INTO FABRICANTE (nome, telefone, cnpj, endereco, email) 
VALUES 
    ('Farmacêutica Ltda.', '6122334455', '12345678901234', 'Avenida dos Remedinhos, 123', 'contato@farmaceuticagenerico.com'),
    ('Laboratório Saúde e Cura', '6188776655', '98765432109876', 'Rua das Fórmulas, 456', 'contato@laboratoriosaudeecura.com'),
    ('Indústria Farmacêutica Bem-Estar Ltda.', '6177889900', '56789012345678', 'Praça da Saúde, 789', 'contato@industriafarmaceuticabemestar.com'),
    ('PharmaVida Produtos Farmacêuticos Ltda.', '6144332211', '34567890123456', 'Alameda das Cápsulas, 321', 'contato@pharmavida.com'),
    ('Laboratório Viver Bem S.A.', '6188990011', '45678901234567', 'Rua das Amostras, 789', 'contato@laboratorioviverbem.com');

INSERT INTO MEDICAMENTO (nome, valor_unidade, estoque, id_fabricante) 
VALUES 
    ('Paracetamol 500mg', 15.90, 100, 1),
    ('Amoxicilina 500mg', 25.50, 50, 2),
    ('Dipirona 500mg', 10.75, 80, 3),
    ('Omeprazol 20mg', 30.00, 60, 4),
    ('Atorvastatina 20mg', 35.25, 40, 5);

INSERT INTO PEDIDO (data, valor_total, id_cliente, id_funcionario) 
VALUES 
    ('2024-04-20', 25.90, 1, 2),
    ('2024-04-21', 35.50, 2, 1),
    ('2024-04-22', 40.00, 3, 3),
    ('2024-04-23', 20.75, 4, 2),
    ('2024-04-24', 28.75, 5, 1);

INSERT INTO INCLUIR (id_pedido, id_medicamento) 
VALUES 
    (1, 1),
    (1, 2),
    (2, 3);

-- ID DO CLIENTE/NOME DO CLIENTE/CPF/EMAIL DO CLIENTE/NASCIMENTO/DIA CADASTRADO/ENDEREÇO/TELEFONE
SELECT id_cliente 'id',  nome 'Nome do Cliente', cpf 'CPF', email 'Email do Cliente', 
data_nascimento 'Data de Nascimento',data_cadastro 'Data de Cadastro', endereco 'Endereço', telefone 'Telefone' from cliente;


-- ----------MEDICAMENTO e FABRICANTE-------------

-- ID DO MEDICAMENTO/NOME DO MEDICAMENTO/NOME DO FORNECEDOR/TELEFONE/EMAIL/CNPJ DO FORNECEDOR/ENDEREÇO/EM ESTOQUE/PREÇO/
SELECT m.id_medicamento AS 'ID', m.nome AS 'Nome do Medicamento', f.nome AS 'Nome do Fornecedor', f.telefone AS 'Telefone',
f.email AS 'Email', f.endereco AS 'Endereço', f.cnpj AS 'CNPJ', m.estoque AS 'Em estoque', m.valor_unidade AS 'Preço Unitário'
FROM MEDICAMENTO m INNER JOIN FABRICANTE f ON m.id_fabricante = f.id_fabricante;
 
-- ------------CARGO-----------

-- ID DO CARGO/CARGO/CARGA HORARIA
SELECT id_cargo AS 'ID', nome_cargo AS 'Cargo', carga_horaria AS 'Carga Horaria' FROM CARGO;

-- ------------FUNCIONARIO-----------

-- ID DO FUNCIONARIO/NOME DO FUNCIONARIO/CPF/EMAIL DO FUNCIONARIO/ENDEREÇO/CARGO/DATA_NASCIMENTO/DATA_CONTRATADO/ATIVO/
SELECT f.id_funcionario AS 'ID', f.nome AS 'Nome do Funcionario', f.cpf AS 'CPF', f.email AS 'Email do Funcionario', 
f.endereco AS 'Endereço', c.nome_cargo AS 'Cargo', f.data_nascimento AS 'Data de Nascimento', 
f.data_contratado AS 'Dia Contratado'FROM FUNCIONARIO f INNER JOIN CARGO c ON c.id_cargo = f.id_cargo;

-- ------------PEDIDO-----------
-- ID DO PEDIDO/DATA DO PEDIDO/VALOR TOTAL/NOME DO CLIENTE/NOME DO FUNCIONARIO/MEDICAMENTOS

SELECT p.id_pedido AS 'ID do Pedido', p.data AS 'Data do Pedido', SUM(m.valor_unidade * (SELECT COUNT(*) FROM INCLUIR i WHERE i.id_pedido = p.id_pedido)
) AS 'Valor Total', c.nome AS 'Nome do Cliente', f.nome AS 'Nome do Funcionário', GROUP_CONCAT(m.nome SEPARATOR ', ') AS 'Medicamentos' FROM PEDIDO p 
INNER JOIN CLIENTE c ON p.id_cliente = c.id_cliente INNER JOIN FUNCIONARIO f ON p.id_funcionario = f.id_funcionario INNER JOIN MEDICAMENTO m 
ON EXISTS ( SELECT 1 FROM INCLUIR i WHERE i.id_medicamento = m.id_medicamento AND i.id_pedido = p.id_pedido) GROUP BY p.id_pedido, p.data, c.nome, f.nome;


